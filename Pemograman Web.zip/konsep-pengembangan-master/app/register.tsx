import { Ionicons } from "@expo/vector-icons";
import * as ImagePicker from "expo-image-picker";
import { useRouter } from "expo-router";
import { createUserWithEmailAndPassword, updateProfile } from "firebase/auth";
import { getDownloadURL, ref, uploadBytes } from "firebase/storage";
import { useState } from "react";
import {
  ActivityIndicator,
  Image,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from "react-native";
import { auth, storage } from "../firebaseConfig";

const uploadImageAsync = async (uri: string, userId: string) => {
  const response = await fetch(uri);
  const blob = await response.blob();
  const fileRef = ref(storage, `avatars/${userId}.jpg`);
  await uploadBytes(fileRef, blob);
  return await getDownloadURL(fileRef);
};

export default function RegisterScreen() {
  const [username, setUsername] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [image, setImage] = useState<string | null>(null);
  const router = useRouter();
  const [loading, setIsLoading] = useState(false);
  const pilihFoto = async () => {
    let result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images,
      allowsEditing: true,
      aspect: [1, 1],
      quality: 1,
    });
    if (!result.canceled && result.assets && result.assets.length > 0) {
      setImage(result.assets[0].uri);
    }
  };
  return (
    <View style={styles.container}>
      <TouchableOpacity
        style={styles.floatingButton}
        onPress={() => {
          router.replace("/");
        }}
      >
        <Ionicons name="arrow-back" size={24} color="white" />
      </TouchableOpacity>
      <Image
        source={require("../assets/images/background.png")}
        style={styles.background}
      />
      <Image
        source={require("../assets/images/logo-text.jpg")}
        style={styles.img}
      />
      <Text style={styles.title}>Daftar Akun</Text>
      <TouchableOpacity style={styles.avatarContainer} onPress={pilihFoto}>
        {image ? (
          <Image source={{ uri: image }} style={styles.avatar} />
        ) : (
          <View style={styles.avatarPlaceholder}>
            <Ionicons name="camera" size={40} color="gray" />
            <Text style={{ fontSize: 10, color: "gray" }}>Tambah Foto</Text>
          </View>
        )}
      </TouchableOpacity>
      <TextInput
        keyboardType="default"
        value={username}
        onChangeText={setUsername}
        style={styles.input}
        placeholder="Username"
      />
      <TextInput
        keyboardType="email-address"
        value={email}
        onChangeText={setEmail}
        style={styles.input}
        placeholder="Email"
      />
      <TextInput
        secureTextEntry={true}
        value={password}
        onChangeText={setPassword}
        style={styles.input}
        placeholder="Password"
      />
      <TouchableOpacity
        style={{ marginBottom: 20, alignSelf: "flex-end", marginRight: 20 }}
      ></TouchableOpacity>

      <TouchableOpacity
        style={styles.button}
        onPress={() => {
          setIsLoading(true);
          createUserWithEmailAndPassword(auth, email, password)
            .then(async (userCredential) => {
              const user = userCredential.user;
              let photoURL = null;

              if (image) {
                photoURL = await uploadImageAsync(image, user.uid);
              }
              await updateProfile(user, {
                displayName: username,
                photoURL: photoURL, 
              });

              alert("Berhasil Daftar sebagai " + username);
              router.replace("/login");
            })
            .catch((error) => {
              setIsLoading(false);
              alert("Gagal Daftar: " + error.message);
            });
        }}
      >
        {loading ? (
          <ActivityIndicator size="small" color="#FFFFFF" />
        ) : (
          <Text style={styles.text}>Daftar</Text>
        )}
      </TouchableOpacity>

      <Image
        style={styles.accountImg}
        source={require("../assets/images/line.jpg")}
      />

      <View style={styles.account}>
        <TouchableOpacity>
          <Image source={require("../assets/images/account/logo-google.png")} />
        </TouchableOpacity>
        <TouchableOpacity>
          <Image source={require("../assets/images/account/logo-fb.png")} />
        </TouchableOpacity>
        <TouchableOpacity>
          <Image source={require("../assets/images/account/logo-x.png")} />
        </TouchableOpacity>
      </View>
      <Text>
        Sudah Punya Akun?
        <TouchableOpacity onPress={() => router.replace("/login")}>
          <Text style={{ color: "#2900f4ff", marginHorizontal: 2 }}>
            Masuk Akun
          </Text>
        </TouchableOpacity>
      </Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    width: "100%",
    height: "100%",
    flexDirection: "column",
    justifyContent: "center",
    alignItems: "center",
  },
  floatingButton: {
    position: "absolute",
    top: 50,
    right: 20,
    width: 50,
    height: 50,
    borderRadius: 25,
    backgroundColor: "#5B3AC7",
    justifyContent: "center",
    alignItems: "center",
    elevation: 5,
    zIndex: 999,
  },
  background: {
    position: "absolute",
    top: 0,
    left: 0,
    bottom: 0,
    right: 0,
    width: "100%",
    height: "100%",
    zIndex: -1,
  },
  img: {
    width: 150,
    height: 103,
    marginHorizontal: "auto",
  },
  title: {
    fontSize: 15,
    fontWeight: "bold",
    marginBottom: 25,
  },
  avatarContainer: {
    width: 100,
    height: 100,
    borderRadius: 50,
    backgroundColor: "#e1e1e1",
    justifyContent: "center",
    alignItems: "center",
    marginBottom: 20,
    overflow: "hidden", // Memastikan gambar tetap di dalam lingkaran
    borderWidth: 1,
    borderColor: "#5B3AC7",
  },
  avatar: {
    width: "100%",
    height: "100%",
  },
  avatarPlaceholder: {
    alignItems: "center",
  },
  input: {
    width: "90%",
    padding: 10,
    borderWidth: 1,
    marginBottom: 10,
    fontSize: 10,
    borderRadius: 5,
  },
  button: {
    backgroundColor: "#5B3AC7",
    paddingHorizontal: 30,
    paddingVertical: 10,
    width: "90%",
    justifyContent: "center",
    alignItems: "center",
    borderRadius: 5,
    marginHorizontal: 2,
    marginTop: 11,
  },
  text: {
    color: "white",
    fontWeight: "bold",
  },
  account: {
    flexDirection: "row",
    justifyContent: "center",
    alignItems: "center",
    gap: 10,
  },
  accountImg: {
    borderRadius: 50,
    elevation: 5,
  },
});
