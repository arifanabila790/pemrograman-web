import { useRouter } from "expo-router";
import { Image, StyleSheet, Text, TouchableOpacity, View } from "react-native";

export default function Index() {
  const router = useRouter();
  return (
    <View style={styles.container}>
      <Image
        source={require("../assets/images/background.png")}
        style={styles.background}
      />
      <View style={ styles.wrapper } >
      <Image
        source={require("../assets/images/logo-text.jpg")}
        style={styles.img}
      />
      <TouchableOpacity
        style={styles.button}
        onPress={() => router.push("/login")}
        activeOpacity={0.7}
      >
        <Text style={styles.text}>Login</Text>
      </TouchableOpacity>
      <TouchableOpacity
        style={styles.button}
        onPress={() => router.push("/register")}
        activeOpacity={0.7}
      >
        <Text style={styles.text}>Daftar</Text>
      </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flexDirection: "column",
    gap: 10,
    flex: 2,
    justifyContent: "center",
    backgroundColor: "white",
    width: "100%",
    marginHorizontal: "auto",
    padding: 20,
  },
  background: {
    position: 'absolute', 
    top: 0,
    left: 0,
    bottom: 0,
    right: 0,
    width: '100%',
    height: '100%',
    zIndex: -1,
  },
  wrapper:{
    flexDirection: "column",
    gap: 10,
    flex: 2,
    justifyContent: "center",
    width: "100%",
    marginHorizontal: "auto",
    padding: 20,
    marginBottom : 100,
  },
  button: {
    backgroundColor: "#5B3AC7",
    paddingHorizontal: 30,
    paddingVertical: 10,
    justifyContent: "center",
    alignItems: "center",
    borderRadius: 5,
  },
  text: {
    color: "white",
    fontWeight: "bold",
  },
  img: {
    width: 150,
    height: 103,
    marginHorizontal: "auto",
  },
});
