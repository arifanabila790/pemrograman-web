import { useRouter } from "expo-router";
import { sendPasswordResetEmail } from "firebase/auth";
import { useState } from "react";
import {
  Image,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
  ActivityIndicator,
} from "react-native";
import { auth } from "../firebaseConfig";
import { Ionicons } from "@expo/vector-icons";

export default function ForgotPasswordScreen() {
  const [email, setEmail] = useState("");
  const router = useRouter();
  const [loading, setIsLoading] = useState(false);
  return (
    <View style={styles.container}>
      <TouchableOpacity
              style={styles.floatingButton}
              onPress={() => { router.replace("/")
              }}
            >
              <Ionicons name="arrow-back" size={24} color="white" />
            </TouchableOpacity>
      <Image
        source={require("../assets/images/background.png")}
        style={styles.background}
      />
      <Text style={styles.title}>Reset Password</Text>
      <TextInput
        keyboardType="email-address"
        value={email}
        onChangeText={setEmail}
        style={styles.input}
        placeholder="Email"
      />
      <TouchableOpacity
        style={styles.button}
        onPress={() => {
          setIsLoading(true);
          sendPasswordResetEmail(auth, email)
            .then(() => {
              setIsLoading(false);
              alert("Link reset kata sandi telah dikirim ke " + email);
              router.replace("/login");
            })
            .catch((error) => {
              setIsLoading(false);
              const errorMessage = error.message;
              alert("Gagal mengirim link reset: " + errorMessage);
            });
        }}
      >
        {loading ? (
          <ActivityIndicator size="small" color="#FFFFFF" />
        ) : (
          <Text style={styles.text}>Reset Password</Text>
        )}
      </TouchableOpacity>

      <Text>
        Coba Masuk Sekarang ?
        <TouchableOpacity onPress={() => router.replace("/login")}>
          <Text style={{ color: "#2900f4ff", marginHorizontal: 2 }}>
            Masuk Akun
          </Text>
        </TouchableOpacity>
      </Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    width: "100%",
    height: "100%",
    flexDirection: "column",
    justifyContent: "center",
    alignItems: "center",
    gap: 10,
  },
  floatingButton: {
    position: "absolute", 
    top: 50,           
    right: 20,           
    width: 50,
    height: 50,
    borderRadius: 25,     
    backgroundColor: "#5B3AC7",
    justifyContent: "center",
    alignItems: "center",
    elevation: 5,         
    zIndex: 999,          
  },
  background: {
    position: "absolute",
    top: 0,
    left: 0,
    bottom: 0,
    right: 0,
    width: "100%",
    height: "100%",
    zIndex: -1,
  },
  title: {
    fontSize: 15,
    fontWeight: "bold",
    marginBottom: 25,
  },
  input: {
    width: "90%",
    padding: 10,
    borderWidth: 1,
    fontSize: 10,
    borderRadius: 5,
    zIndex: 1000,
  },
  button: {
    backgroundColor: "#5B3AC7",
    paddingHorizontal: 30,
    paddingVertical: 10,
    width: "90%",
    justifyContent: "center",
    alignItems: "center",
    borderRadius: 5,
    marginHorizontal: 2,
  },
  text: {
    color: "white",
    fontWeight: "bold",
  },
});
