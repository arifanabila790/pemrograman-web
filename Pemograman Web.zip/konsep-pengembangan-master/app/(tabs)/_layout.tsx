import { Ionicons } from "@expo/vector-icons";
import { BottomTabBarProps } from "@react-navigation/bottom-tabs";
import { Tabs } from "expo-router";
import React from "react";
import { StyleSheet, TouchableOpacity, View } from "react-native";

// 1. Komponen Custom Tab Bar
function CustomTabBar({ state, navigation }: BottomTabBarProps) {
  return (
    <View style={styles.container}>
      {/* Tombol Dashboard */}
      <TouchableOpacity
        style={styles.item}
        // HAPUS TANDA "/" DISINI
        onPress={() => navigation.navigate("dashboard")}
      >
        <Ionicons
          name={state.index === 0 ? "home": "home-outline"}
          size={24}
          color="black"
        />
      </TouchableOpacity>

      {/* Tombol Activity */}
      <TouchableOpacity
        style={styles.item}
        // HAPUS TANDA "/" DISINI
        onPress={() => navigation.navigate("activity")}
      >
        <Ionicons
          name={state.index === 1 ? "clipboard" : "clipboard-outline"}
          size={24}
          color="black"
        />
      </TouchableOpacity>

      {/* Tombol Tengah (Job List) */}
      <View style={styles.itemUp}>
        <TouchableOpacity
          style={styles.item}
          // HAPUS TANDA "/" DISINI
          onPress={() => navigation.navigate("jobList")}
        >
          {/* NOTE: Saya ubah warnanya tetap 'white' agar terlihat jelas 
             karena background tombolnya sudah ungu (#5B3AC7).
             Jika diubah ke ungu saat aktif, iconnya malah akan hilang (samar).
          */}
          <Ionicons
            name={state.index === 2 ? "briefcase" : "briefcase-outline"}
            size={24}
            color="white"
          />
        </TouchableOpacity>
      </View>

      {/* Tombol Chat */}
      <TouchableOpacity
        style={styles.item}
        // HAPUS TANDA "/" DISINI
        onPress={() => navigation.navigate("chat")}
      >
        <Ionicons
          name={state.index === 3 ? "chatbubbles" : "chatbubbles-outline"}
          size={24}
          color="black"
        />
      </TouchableOpacity>

      {/* Tombol Profile */}
      <TouchableOpacity
        style={styles.item}
        // HAPUS TANDA "/" DISINI
        onPress={() => navigation.navigate("profile")}
      >
        <Ionicons
          name={state.index === 4 ? "person":"person-outline"}
          size={24}
          color="black"
        />
      </TouchableOpacity>
    </View>
  );
}

// 2. Layout Utama
export default function Layout() {
  return (
    <Tabs
      screenOptions={{ headerShown: false }}
      tabBar={(props) => <CustomTabBar {...props} />}
    >
      {/* Nama di sini ("dashboard", "activity", dll) adalah KUNCI navidasi */}
      <Tabs.Screen name="dashboard" options={{ title: "Home" }} />
      <Tabs.Screen name="activity" options={{ title: "Activity" }} />
      <Tabs.Screen name="jobList" options={{ title: "Jobs" }} />
      <Tabs.Screen name="chat" options={{ title: "Chat" }} />
      <Tabs.Screen name="profile" options={{ title: "Profile" }} />

      <Tabs.Screen name="explore" options={{ href: null }} />
      <Tabs.Screen name="forgotPassword" options={{ href: null }} />
    </Tabs>
  );
}

// 3. Styling
const styles = StyleSheet.create({
  container: {
    position: "absolute",
    bottom: 0,
    width: "100%",
    height: 60,
    backgroundColor: "white",
    justifyContent: "space-evenly",
    alignItems: "center",
    flexDirection: "row",
    borderTopWidth: 1,
    borderTopColor: "#eee",
    elevation: 5,
    shadowColor: "black",
    shadowOffset: {width: 1, height: 1},
    shadowRadius: 1,
  },
  item: {
    justifyContent: "center",
    alignItems: "center",
  },
  itemUp: {
    height: 80,
    width: 80,
    backgroundColor: "#5B3AC7",
    justifyContent: "center",
    alignItems: "center",
    borderRadius: 45,
    borderWidth: 7,
    borderColor: "#f2f2f2",
    marginBottom: 65,
  },
});
