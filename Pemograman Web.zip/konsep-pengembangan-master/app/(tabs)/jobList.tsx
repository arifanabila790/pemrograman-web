import { Ionicons } from "@expo/vector-icons";
import { LinearGradient } from "expo-linear-gradient";
import { useRouter } from "expo-router";
import { collection, getDocs } from "firebase/firestore";
import { useEffect, useState } from "react";
import {
  Dimensions,
  FlatList,
  Image,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from "react-native";
import Carousel from "react-native-reanimated-carousel";
import { auth, db } from "../../firebaseConfig";
interface Job {
  id: string;
  title: string;
  company: string;
  location: string;
  salary: string;
  image: any;
  category: string;
}

const HeaderComponent = ({
  selectedCategory,
  setSelectedCategory,
  categories,
  searchQuery,
  setSearchQuery,
  userImage,
}: any) => {
  const width = Dimensions.get("window").width;
  const banners = [
    {
      id: 1,
      image:
        "https://images.unsplash.com/photo-1517694712202-14dd9538aa97?w=500&q=80",
    },
    {
      id: 2,
      image:
        "https://images.unsplash.com/photo-1605379399642-870262d3d051?w=500&q=80",
    },
    {
      id: 3,
      image:
        "https://images.unsplash.com/photo-1461749280684-dccba630e2f6?w=500&q=80",
    },
  ];
  return (
    <View style={{ width: "100%" }}>
      <LinearGradient
        colors={["#DAD4F2", "#5837c5d3", "#E5DEFA"]}
        start={{ x: 1, y: 1 }}
        end={{ x: -1, y: -1 }}
        style={styles.container}
      >
        <View style={styles.nav}>
          <Ionicons name="menu-sharp" size={35} style={styles.menu} />
          <Text style={styles.heading}>KarirQ</Text>
          <TouchableOpacity>
            <Image
              style={styles.user}
              source={
                userImage
                  ? { uri: userImage }
                  : require("../../assets/images/user.png")
              }
            />
          </TouchableOpacity>
        </View>
        <View style={styles.search}>
          <TextInput
            placeholder="Cari Lowongan"
            style={styles.input}
            value={searchQuery}
            onChangeText={(text) => setSearchQuery(text)}
          />
          <Ionicons
            style={styles.srcButton}
            name="search"
            color="white"
            size={20}
          />
        </View>
      </LinearGradient>
      <Carousel
        width={width}
        height={120}
        data={banners}
        renderItem={({ item }) => (
          <Image
            style={styles.banners}
            resizeMode="cover"
            source={{ uri: item.image }}
          />
        )}
      />
      <View style={styles.filter}>
        <TouchableOpacity style={styles.filterIcon}>
          <Ionicons name="options-outline" size={20} />
        </TouchableOpacity>
        <FlatList
          data={categories}
          horizontal
          showsHorizontalScrollIndicator={false}
          style={{ paddingBottom: 10 }}
          renderItem={({ item }) => (
            <TouchableOpacity
              onPress={() =>
                setSelectedCategory(item === selectedCategory ? "all" : item)
              }
              style={[
                styles.categoryButton,
                item === selectedCategory
                  ? { backgroundColor: "#3D2196" }
                  : { backgroundColor: "#5B3AC7" },
              ]}
            >
              <Text style={styles.categoryText}>{item}</Text>
            </TouchableOpacity>
          )}
        />
      </View>
    </View>
  );
};

export default function TabOneScreen() {
  const [user, setUser] = useState(auth.currentUser);

  useEffect(() => {
    // 2. Pantau perubahan status login (onAuthStateChanged)
    const unsubscribe = auth.onAuthStateChanged((userFound) => {
      setUser(userFound);
    });

    return unsubscribe; 
  }, []);

  const userPhoto = user?.photoURL;
  console.log("Cek Link Foto User:", userPhoto);
  const router = useRouter();

  const [selectedCategory, setSelectedCategory] = useState("all");

  const [jobs, setJobs] = useState<Job[]>([]);

  const categoriesFromData = [...new Set(jobs.map((job) => job.category))];

  const [searchQuery, setSearchQuery] = useState("");

  const allCategoriesFromJobs = jobs.map((job) => job.category);
  const uniqueCategories = [...new Set(allCategoriesFromJobs)];

  const dynamicCategories = ["all", ...uniqueCategories];

  const filteredJobs = jobs.filter((job) => {
    const categoryMatch =
      selectedCategory === "all" || job.category === selectedCategory;

    const searchMatch = job.title
      .toLowerCase()
      .includes(searchQuery.toLowerCase());

    return categoryMatch && searchMatch;
  });

  useEffect(() => {
    const ambilData = async () => {
      try {
        const querySnapshot = await getDocs(collection(db, "jobs"));

        console.log("🔥 STATUS KONEKSI 🔥");
        console.log("Jumlah Data ditemukan:", querySnapshot.size);

        const dataLowongan = querySnapshot.docs.map((doc) => {
          const data = doc.data();
          console.log("Isi Data:", data);
          return {
            id: doc.id,
            title: data.title,
            company: data.company,
            location: data.location,
            salary: data.salary,
            image: data.image,
            category: data.category,
          } as Job;
        });
        setJobs(dataLowongan);
      } catch (error) {
        console.error("❌ ERROR SAAT AMBIL DATA:", error);
      }
    };
    ambilData();
  }, []);

  return (
    <View
      style={{
        flex: 1,
        backgroundColor: "#f2f2f2",
      }}
    >
      <HeaderComponent
        userImage={userPhoto}
        selectedCategory={selectedCategory}
        setSelectedCategory={setSelectedCategory}
        categories={dynamicCategories}
        searchQuery={searchQuery}
        setSearchQuery={setSearchQuery}
      />
      <FlatList
        data={filteredJobs}
        keyExtractor={(item) => item.id}
        contentContainerStyle={{ paddingBottom: 65 }}
        renderItem={({ item }) => (
          <TouchableOpacity style={styles.jobLeft}>
            <View style={styles.logo}>
              {item.image ? (
                <Image
                  style={{ width: "100%", height: "100%", borderRadius: "50%" }}
                  source={item.image}
                />
              ) : (
                <Image
                  source={require("../../assets/images/PT-null.png")}
                  style={{ width: "100%", height: "100%", borderRadius: "50%" }}
                />
              )}
            </View>
            <View style={styles.jobCenter}>
              <Text style={styles.title}>{item.title}</Text>
              <Text style={styles.location}>
                {item.company} - {item.location}
              </Text>
            </View>
            <View style={styles.jobRight}>
              <Text style={styles.salary}>{item.salary}</Text>
              <Ionicons
                name="caret-forward-outline"
                size={20}
                color={"black"}
                style={{ position: "absolute", left: 65, bottom: 17 }}
              />
            </View>
          </TouchableOpacity>
        )}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    width: "100%",
    height: 150,
    borderBottomLeftRadius: 50,
    borderBottomRightRadius: 50,
    shadowOffset: { width: 0, height: 2 },
    shadowRadius: 5,
    shadowOpacity: 10,
    padding: 10,
  },
  nav: {
    display: "flex",
    flexDirection: "row",
    justifyContent: "space-between",
    alignContent: "center",
  },
  menu: {
    alignContent: "center",
  },
  heading: {
    fontSize: 25,
    fontWeight: "bold",
    alignContent: "center",
    width: "100%",
    paddingLeft: 15,
  },
  user: {
    height: 50,
    width: 50,
    borderRadius: 25,
    borderWidth: 2,
    borderColor: "gray",
  },
  search: {
    display: "flex",
    flexDirection: "row",
    justifyContent: "center",
    marginTop: 25,
  },
  input: {
    backgroundColor: "#9d8ecc9a",
    padding: 10,
    paddingLeft: 15,
    borderBottomLeftRadius: 20,
    borderTopLeftRadius: 20,
    color: "white",
    width: "85%",
    fontSize: 15,
  },
  srcButton: {
    padding: 10,
    paddingRight: 15,
    backgroundColor: "#9d8ecc9a",
    borderBottomRightRadius: 20,
    borderTopRightRadius: 20,
  },
  banners: {
    width: "90%",
    height: 100,
    margin: "auto",
    borderRadius: 20,
  },
  filter: {
    display: "flex",
    flexDirection: "row",
    paddingHorizontal: 10,
  },
  filterIcon: {
    borderRadius: 5,
    height: "77%",
    paddingHorizontal: 7,
    marginRight: 5,
    justifyContent: "center",
    alignContent: "center",
    shadowOffset: { width: 1, height: 1 },
    shadowRadius: 10,
    shadowOpacity: 0.5,
  },
  categoryButton: {
    backgroundColor: "#5B3AC7",
    marginHorizontal: 5,
    paddingHorizontal: 10,
    paddingVertical: 6,
    borderRadius: 5,
    shadowOffset: { width: 1, height: 1 },
    shadowRadius: 10,
    shadowOpacity: 0.5,
  },
  categoryText: {
    color: "white",
  },
  jobLeft: {
    display: "flex",
    flexDirection: "row",
    padding: 10,
    borderRadius: 10,
    shadowOffset: { width: 1, height: 1 },
    shadowRadius: 6,
    marginVertical: 5,
    marginHorizontal: 10,
  },
  jobCenter: {
    marginLeft: 10,
    width: "55%",
  },
  jobRight: {
    position: "relative",
  },
  logo: {
    width: 55,
    height: 55,
    borderRadius: "50%",
    justifyContent: "center",
    alignContent: "center",
    borderWidth: 2,
    borderColor: "gray",
  },
  title: {
    fontWeight: "bold",
    fontSize: 15,
  },
  location: {
    fontSize: 10,
  },
  salary: {
    position: "absolute",
    left: 0,
    bottom: 0,
    color: "#5B3AC7",
    fontWeight: "bold",
    fontSize: 10,
  },
});
