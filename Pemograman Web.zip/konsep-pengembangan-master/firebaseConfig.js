import { initializeApp } from "firebase/app";
import { getAuth } from "firebase/auth";
import { getFirestore } from "firebase/firestore";
import { getStorage } from "firebase/storage";

const firebaseConfig = {
  apiKey: "AIzaSyDMzDKVIg7ZTvrWXL-RjgLpg75GA3KkK7Y",
  authDomain: "karirq-11111.firebaseapp.com",
  projectId: "karirq-11111",
  storageBucket: "karirq-11111.firebasestorage.app",
  messagingSenderId: "466428084866",
  appId: "1:466428084866:web:c8b860fa7d7cde55cfaa9b"
};

const app = initializeApp(firebaseConfig);

export const auth = getAuth(app);
export const db = getFirestore(app);
export const storage = getStorage(app);